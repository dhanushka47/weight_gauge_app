class QuotationItem {
  String description;
  String color;
  String material;
  String infill;
  String grams;
  String pricePerGram;

  QuotationItem({
    this.description = '',
    this.color = '',
    this.material = '',
    this.infill = '',
    this.grams = '',
    this.pricePerGram = '',
  });
}
